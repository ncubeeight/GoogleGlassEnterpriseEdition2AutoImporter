#!/bin/bash
# Watches for Google Glass EE2 over USB (adb) and auto-imports new photos/videos.
# Successfully-imported files are moved into a hidden .imported/ folder on the
# device (not deleted) so the camera roll clears out without destroying data.

set -u

# Locate adb: check common install locations, then fall back to PATH.
ADB_CANDIDATES=(
    "$HOME/Library/Android/sdk/platform-tools/adb"
    "/opt/homebrew/bin/adb"
    "/usr/local/bin/adb"
)
ADB=""
for c in "${ADB_CANDIDATES[@]}"; do
    if [ -x "$c" ]; then ADB="$c"; break; fi
done
if [ -z "$ADB" ]; then
    ADB="$(command -v adb || true)"
fi
if [ -z "$ADB" ]; then
    echo "adb not found. Install Android platform-tools (e.g. 'brew install android-platform-tools') and re-run." >&2
    exit 1
fi

DEST="$HOME/Pictures/GoogleGlass"
DEST_MOVIES="$DEST/Movies"
REMOTE_PICTURES="/sdcard/Pictures"
REMOTE_MOVIES="/sdcard/Movies"
TARGET_MODEL="Glass Enterprise Edition 2"
LOG="$HOME/Library/Logs/glass-import.log"

mkdir -p "$DEST" "$DEST_MOVIES"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"; }

notify() {
    osascript -e "display notification \"$1\" with title \"Google Glass Import\""
}

log "Watcher started (adb: $ADB)"

while true; do
    "$ADB" wait-for-usb-device 2>>"$LOG"

    # Give the device a moment and confirm it's actually the Glass (not some other Android device)
    sleep 2
    MODEL=$("$ADB" shell getprop ro.product.model 2>/dev/null | tr -d '\r')

    if [ "$MODEL" != "$TARGET_MODEL" ]; then
        log "Connected device is '$MODEL', not Glass — ignoring"
        "$ADB" wait-for-disconnect 2>>"$LOG"
        continue
    fi

    log "Glass connected, checking for new photos/videos"

    NEW_COUNT=0

    import_dir() {
        local remote="$1" local_dest="$2" archive="$1/.imported"
        local files
        "$ADB" shell mkdir -p "$archive" >>"$LOG" 2>&1
        files=$("$ADB" shell ls "$remote" 2>/dev/null | tr -d '\r')
        while IFS= read -r f; do
            [ -z "$f" ] && continue
            if [ ! -f "$local_dest/$f" ]; then
                "$ADB" pull -a "$remote/$f" "$local_dest/$f" >>"$LOG" 2>&1
                if [ $? -eq 0 ] && [ "$(stat -f%z "$local_dest/$f" 2>/dev/null)" = "$("$ADB" shell stat -c%s "$remote/$f" 2>/dev/null | tr -d '\r')" ]; then
                    "$ADB" shell mv "$remote/$f" "$archive/$f" >>"$LOG" 2>&1
                    NEW_COUNT=$((NEW_COUNT + 1))
                else
                    log "Size mismatch or pull failure for $f — leaving on device, not archiving"
                fi
            fi
        done <<< "$files"
    }

    import_dir "$REMOTE_PICTURES" "$DEST"
    import_dir "$REMOTE_MOVIES" "$DEST_MOVIES"

    if [ "$NEW_COUNT" -gt 0 ]; then
        log "Imported $NEW_COUNT new file(s) to $DEST"
        notify "Imported $NEW_COUNT new file(s)"
    else
        log "No new photos/videos"
    fi

    "$ADB" wait-for-disconnect 2>>"$LOG"
    log "Glass disconnected"
done
