Google Glass EE2 Auto-Import for macOS
=======================================

What this does
--------------
Runs quietly in the background and watches for a Google Glass Enterprise
Edition 2 to connect over USB. When it does, it automatically copies any
new photos and videos to:

    ~/Pictures/GoogleGlass/            (photos)
    ~/Pictures/GoogleGlass/Movies/     (videos)

Each file's size is verified against the copy on the Glass before it is
considered imported. Successfully imported files are then moved into a
hidden .imported/ folder on the Glass itself (NOT deleted) so they clear
out of the camera roll without any risk of permanent data loss. You can
manually clear that archive later if you want to reclaim space — see
"Freeing up space on the Glass" below.

A macOS notification appears whenever new files are imported.

Requirements
------------
- macOS
- adb (Android Debug Bridge). If you don't already have it:
      brew install android-platform-tools
  (Or it will be auto-detected if installed via Android Studio's SDK.)
- USB debugging enabled on the Glass, and the "Allow USB debugging" prompt
  accepted on the Glass display the first time it's plugged into a new Mac.

Install on a new Mac
---------------------
1. Copy this whole "GlassAutoImport" folder to the Mac (USB drive, AirDrop,
   whatever's convenient).
2. Open Terminal, cd into the folder, and run:

       ./install.sh

3. Plug in the Glass. Accept the USB debugging prompt on its display when
   it appears. Photos/videos should import within a few seconds.

The installer figures out the right paths for whichever user account runs
it — nothing is hardcoded to a specific Mac or username.

Uninstall
---------
From the folder, run:

    ./uninstall.sh

This stops the background watcher and removes it from login items. Your
already-imported photos/videos are left untouched.

Freeing up space on the Glass
------------------------------
The watcher never deletes anything on the Glass automatically. Once you're
confident everything you care about has been imported, you can manually
clear the archive folders yourself (irreversible):

    adb shell rm -rf /sdcard/Pictures/.imported /sdcard/Movies/.imported

Troubleshooting
----------------
Log file: ~/Library/Logs/glass-import.log
- "unauthorized" in `adb devices -l`: accept the prompt on the Glass display.
- Nothing imports: confirm the Glass's model name matches "Glass Enterprise
  Edition 2" via `adb shell getprop ro.product.model` — the watcher ignores
  any other Android device to avoid pulling from the wrong gadget.
